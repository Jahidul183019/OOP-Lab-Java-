public class Monkey extends Animal {
    public Monkey(String name, int age){ super(name, age); }
    @Override public String makeSound(){ return "Chatter"; }
}
